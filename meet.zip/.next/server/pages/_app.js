/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./context/socket.js":
/*!***************************!*\
  !*** ./context/socket.js ***!
  \***************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   SocketProvider: () => (/* binding */ SocketProvider),\n/* harmony export */   useSocket: () => (/* binding */ useSocket)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! socket.io-client */ \"socket.io-client\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([socket_io_client__WEBPACK_IMPORTED_MODULE_2__]);\nsocket_io_client__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nconst SocketContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);\n//instead of defining in where we use in app, we are defining here and we can call it (just to decrease redundancy)\nconst useSocket = ()=>{\n    const gotSocket = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(SocketContext);\n    return gotSocket;\n};\nfunction SocketProvider(props) {\n    const { children } = props;\n    const [socket, setSocket] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        const connection = (0,socket_io_client__WEBPACK_IMPORTED_MODULE_2__.io)({\n            path: \"/api/socket\"\n        });\n        setSocket(connection);\n        console.log(connection);\n    }, []);\n    socket?.on(\"connect_error\", async (err)=>{\n        console.log(\"Errror Establishing\", err);\n        await fetch(\"/api/socket\");\n    });\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(SocketContext.Provider, {\n        value: socket,\n        children: children\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\chakri wayne\\\\Documents\\\\Meet clone\\\\google-meet-clone\\\\context\\\\socket.js\",\n        lineNumber: 30,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb250ZXh0L3NvY2tldC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFzRTtBQUNsQztBQUVwQyxNQUFNSyw4QkFBZ0JMLG9EQUFhQSxDQUFDO0FBRXBDLG1IQUFtSDtBQUM1RyxNQUFNTSxZQUFXO0lBQ3BCLE1BQU1DLFlBQVlOLGlEQUFVQSxDQUFDSTtJQUM3QixPQUFPRTtBQUNYLEVBQUM7QUFFTSxTQUFTQyxlQUFlQyxLQUFLO0lBRWhDLE1BQU0sRUFBQ0MsUUFBUSxFQUFDLEdBQUdEO0lBRW5CLE1BQU0sQ0FBQ0UsUUFBT0MsVUFBVSxHQUFJVCwrQ0FBUUEsQ0FBQztJQUVyQ0QsZ0RBQVNBLENBQUM7UUFDUixNQUFNVyxhQUFhVCxvREFBRUEsQ0FBQztZQUFDVSxNQUFLO1FBQWE7UUFDdkNGLFVBQVVDO1FBQ1ZFLFFBQVFDLEdBQUcsQ0FBQ0g7SUFDaEIsR0FBRyxFQUFFO0lBRUxGLFFBQVFNLEdBQUcsaUJBQWlCLE9BQU9DO1FBQy9CSCxRQUFRQyxHQUFHLENBQUMsdUJBQXVCRTtRQUNuQyxNQUFNQyxNQUFNO0lBQ2hCO0lBRUYscUJBQ0UsOERBQUNkLGNBQWNlLFFBQVE7UUFBQ0MsT0FBT1Y7a0JBQzFCRDs7Ozs7O0FBR1QiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9nb29nbGUtbWVldC1jbG9uZS8uL2NvbnRleHQvc29ja2V0LmpzP2FiMDYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiXHJcbmltcG9ydCB7aW8gfSBmcm9tIFwic29ja2V0LmlvLWNsaWVudFwiXHJcblxyXG5jb25zdCBTb2NrZXRDb250ZXh0ID0gY3JlYXRlQ29udGV4dChudWxsKVxyXG5cclxuLy9pbnN0ZWFkIG9mIGRlZmluaW5nIGluIHdoZXJlIHdlIHVzZSBpbiBhcHAsIHdlIGFyZSBkZWZpbmluZyBoZXJlIGFuZCB3ZSBjYW4gY2FsbCBpdCAoanVzdCB0byBkZWNyZWFzZSByZWR1bmRhbmN5KVxyXG5leHBvcnQgY29uc3QgdXNlU29ja2V0ID0oKSA9PiB7XHJcbiAgICBjb25zdCBnb3RTb2NrZXQgPSB1c2VDb250ZXh0KFNvY2tldENvbnRleHQpXHJcbiAgICByZXR1cm4gZ290U29ja2V0O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU29ja2V0UHJvdmlkZXIocHJvcHMpIHtcclxuXHJcbiAgICBjb25zdCB7Y2hpbGRyZW59ID0gcHJvcHM7XHJcblxyXG4gICAgY29uc3QgW3NvY2tldCxzZXRTb2NrZXRdICA9IHVzZVN0YXRlKG51bGwpXHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgY29uc3QgY29ubmVjdGlvbiA9IGlvKHtwYXRoOicvYXBpL3NvY2tldCd9KTtcclxuICAgICAgICBzZXRTb2NrZXQoY29ubmVjdGlvbilcclxuICAgICAgICBjb25zb2xlLmxvZyhjb25uZWN0aW9uKVxyXG4gICAgfSwgW10pXHJcblxyXG4gICAgc29ja2V0Py5vbihcImNvbm5lY3RfZXJyb3JcIiwgYXN5bmMgKGVycikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiRXJycm9yIEVzdGFibGlzaGluZ1wiLCBlcnIpXHJcbiAgICAgICAgYXdhaXQgZmV0Y2goJy9hcGkvc29ja2V0JylcclxuICAgIH0pXHJcbiAgICBcclxuICByZXR1cm4gKFxyXG4gICAgPFNvY2tldENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3NvY2tldH0+XHJcbiAgICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9Tb2NrZXRDb250ZXh0LlByb3ZpZGVyPlxyXG4gIClcclxufVxyXG4iXSwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImlvIiwiU29ja2V0Q29udGV4dCIsInVzZVNvY2tldCIsImdvdFNvY2tldCIsIlNvY2tldFByb3ZpZGVyIiwicHJvcHMiLCJjaGlsZHJlbiIsInNvY2tldCIsInNldFNvY2tldCIsImNvbm5lY3Rpb24iLCJwYXRoIiwiY29uc29sZSIsImxvZyIsIm9uIiwiZXJyIiwiZmV0Y2giLCJQcm92aWRlciIsInZhbHVlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./context/socket.js\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _context_socket__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/context/socket */ \"./context/socket.js\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_socket__WEBPACK_IMPORTED_MODULE_1__]);\n_context_socket__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_context_socket__WEBPACK_IMPORTED_MODULE_1__.SocketProvider, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\chakri wayne\\\\Documents\\\\Meet clone\\\\google-meet-clone\\\\pages\\\\_app.js\",\n                lineNumber: 7,\n                columnNumber: 5\n            }, this),\n            \";\"\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\chakri wayne\\\\Documents\\\\Meet clone\\\\google-meet-clone\\\\pages\\\\_app.js\",\n        lineNumber: 6,\n        columnNumber: 3\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBa0Q7QUFDcEI7QUFFZixTQUFTQyxJQUFJLEVBQUVDLFNBQVMsRUFBRUMsU0FBUyxFQUFFO0lBQ2xELHFCQUNBLDhEQUFDSCwyREFBY0E7OzBCQUNiLDhEQUFDRTtnQkFBVyxHQUFHQyxTQUFTOzs7Ozs7WUFBSTs7Ozs7OztBQUloQyIsInNvdXJjZXMiOlsid2VicGFjazovL2dvb2dsZS1tZWV0LWNsb25lLy4vcGFnZXMvX2FwcC5qcz9lMGFkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNvY2tldFByb3ZpZGVyIH0gZnJvbSBcIkAvY29udGV4dC9zb2NrZXRcIjtcbmltcG9ydCBcIkAvc3R5bGVzL2dsb2JhbHMuY3NzXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcbiAgcmV0dXJuKFxuICA8U29ja2V0UHJvdmlkZXI+XG4gICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPjtcbiAgICBcbiAgPC9Tb2NrZXRQcm92aWRlcj5cbiAgKVxufVxuIl0sIm5hbWVzIjpbIlNvY2tldFByb3ZpZGVyIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "socket.io-client":
/*!***********************************!*\
  !*** external "socket.io-client" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = import("socket.io-client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();